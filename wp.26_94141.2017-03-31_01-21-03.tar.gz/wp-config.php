<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'eniaaruj_vms');

/** MySQL database username */
define('DB_USER', 'eniaaruj_vms');

/** MySQL database password */
define('DB_PASSWORD', 'pSy586!3!8');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '1z9fqluexu57aeqkyrnovtnnlkh8zwtbyw140ogujrnj86xbjbwcqef31o3k1me2');
define('SECURE_AUTH_KEY',  'smiapyqzk2ew1izc6p7evary7hrvwwul7ixrwnv1odylrz7julp68by3nxbsma2a');
define('LOGGED_IN_KEY',    'cqlvcx7tu4ztvh8qw1kbw76ughnzljgngeiwbzyoegjaaastfiro9otwpmfbvbi9');
define('NONCE_KEY',        'd7rqddtdclflnaw6yeaqho9kjtp5d1yfgmotuv9j9bjo2njikkftzcbav596mu64');
define('AUTH_SALT',        'nmntjzr5uqgjaaovxoaobyr4ggkg48t2kfzfrulscc7lu9ezfcpt4qsvko9awxe2');
define('SECURE_AUTH_SALT', 'rz8cpw8dvf5s3g5rvfyxv6lwgnxmwrwnsetg2idmiiha2i0yyk9hbqulvosyzmrb');
define('LOGGED_IN_SALT',   'qt4hvd9xku2hkzkufbrjrerk6gjp4bwq81x89qwbbq77pkktto16i36isyiacnzk');
define('NONCE_SALT',       'odtje9wq9jw4sclrsemgu8kbavsccxsf9bprv7ytdv6tfhslnuzyprzf6ocq1gsi');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'vms_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
